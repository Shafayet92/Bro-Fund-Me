import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/ProcessOrder"})
public class ProcessOrder extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Cookie[] cookies = null;
        cookies = request.getCookies();
        String name = "";
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                if (cookie.getName().equals("user_name")) {
                    name = cookie.getValue();
                } else if (cookie.getName().equals("phone_no")) {
                    cookie.setMaxAge(0);
                }
            }
        }
        HttpSession session = request.getSession();
        String email=(String)session.getAttribute("email");
        String set1=request.getParameter("Set1Checkbox");
        String set2=request.getParameter("Set2Checkbox");
        String set3=request.getParameter("Set3Checkbox");

        String set1Size=request.getParameter("set1SizeOption");
        String set2Size=request.getParameter("set2SizeOption");
        String set3Size=request.getParameter("set3SizeOption");

        String set1Quantity=request.getParameter("set1OrderQuantity");
        String set2Quantity=request.getParameter("set2OrderQuantity");
        String set3Quantity=request.getParameter("set3OrderQuantity");
        double amount=0;
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProfileServlet</title>");
            out.println("<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\">    ");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Your Order Detail</h1>");
            out.println("User Name: " + name);
            out.println("<br>");
            out.println("Email: " + email);
            out.println("<br>");

            out.println("    <table class=\"table table-dark\" >\n"
                    + "        <tr>\n"
                    + "            <td>Uniform Set</td>\n"
                    + "            <td> Size</td>\n"
                    + "            <td>Quantity</td>           \n"
                    + "            <td>Price</td>           \n"
                    + "        </tr>\n"
                    + "        \n");
            
            if(set1!=null){
                if(set1Size.equals("S")){
                    amount+=30;
                }else if (set1Size.equals("M")) {
                    amount += 31;
                }else if (set1Size.equals("L")) {
                    amount += 32;
                }else if (set1Size.equals("XL")) {
                    amount += 33;
                }



                out.println( "    <tr>\n"
                        + "            <td>"+set1+"</td>\n"
                        + "            <td>"+set1Size+"</td>\n"
                        + "            <td>"+set1Quantity+"</td>           \n"
                        + "            <td>"+Double.toString(amount)+"</td>           \n"
                        + "        </tr>\n"
                        + "        \n");
    
            }
            if (set2 != null) {
                out.println("    <tr>\n"
                        + "            <td>" + set2 + "</td>\n"
                        + "            <td>" + set2Size + "</td>\n"
                        + "            <td>" + set2Quantity + "</td>           \n"
                        + "            <td>" + "RM123" + "</td>           \n"
                        + "        </tr>\n"
                        + "        \n");

            }
            if (set3 != null) {
                out.println("    <tr>\n"
                        + "            <td>" + set3 + "</td>\n"
                        + "            <td>" + set3Size + "</td>\n"
                        + "            <td>" + set3Quantity + "</td>           \n"
                        + "            <td>" + "RM123" + "</td>           \n"
                        + "        </tr>\n"
                        + "        \n");

            }
            out.println("</table>");
            out.println("<h6>Total Amount To Pay = RM"+Double.toString(amount)+"</h6>");
            out.println("<a class=\"btn btn-success\" type=\"submit\" href=\"index.jsp\">Home</a>");

            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
